--[[
I've removed all the AI generated code to approach this with sanity and
intention.
]]

--[[
This file is for wiring the `core` functions which are not related to the WoW
API and the `wow` functions which are related to the WoW API.
]]

require "core/schema.lua"  -- for SCHEMA_VERSION
require "wow/dumper.lua"  -- for BronzeScrape_DumpTalentsRaw
