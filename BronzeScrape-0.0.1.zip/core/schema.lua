local SCHEMA_VERSION = 1

local meta = {}

local talents = {}
local spells = {}
local glyphs = {}
